package com.example.demo.service;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.demo.model.Creator;

public class CreatorDetailsServiceImpl implements UserDetails  {
	
	private Creator creator;
	
	public CreatorDetailsServiceImpl(Creator creator) {
		this.creator=creator;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return Collections.singleton(new SimpleGrantedAuthority("CREATOR"));  // define single role as "CREATOR"
	}

	@Override
	public String getPassword() {
		return creator.getPassword();
	}

	@Override
	public String getUsername() {
		return creator.getEmail();
	}

}
