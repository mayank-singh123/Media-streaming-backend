package com.example.demo.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor 
public class Video {
		private Integer videosId;
		
	    private String title; 
	    
	    private String overview; 
	    
	    private String posterPath;   // Thumbnail
	    
	    private String videoUrl;  // actual video
	    
	    private String releaseDate = new Date().toString(); 
	    
	    private float voteAverage = 0.0f; 
	    private int voteCount = 0; 
	    private String runtime; 
	    private String language;
	    
	    private Long totalWatchTime = 0L;  
	    
	    private String category;
	    
	    private Integer creatorId;
	    
	    private List<Image> images = new ArrayList<Image>();
	    
	    private List<Short> shorts = new ArrayList<Short>();
	    
	    private List<Cast> cast = new ArrayList<Cast>();
	    
	    private List<String> genres = new ArrayList<String>();
	    
		private List<String> likes = new ArrayList<String>();  // list of userIds that likes this video
		
		private List<String> favourites = new ArrayList<String>();  // // list of userIds that add to fav this video
		
		private List<Viewer> views = new ArrayList<Viewer>();  // // list of userIds that views this video
		
	    private List<Comment> comments = new ArrayList<Comment>();
}



