package com.example.demo.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Viewer {
	
	private String email;
	private String gender;
	private int age;
	private String location;  //  updated the view only first time in a video
	private String device;
	
	private Date firstViewedDate = new Date();   // extract views by month for analytics
	
}
