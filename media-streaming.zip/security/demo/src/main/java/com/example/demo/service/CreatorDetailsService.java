package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.model.Creator;
import com.example.demo.repository.CreatorRepo;

@Service
public class CreatorDetailsService implements UserDetailsService {

	@Autowired
	private CreatorRepo creatorRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Creator creator = creatorRepo.findByEmail(username);
		if(creator == null) {
			throw new UsernameNotFoundException("Creator Not Found");
		}
		return new CreatorDetailsServiceImpl(creator);
	}

}
