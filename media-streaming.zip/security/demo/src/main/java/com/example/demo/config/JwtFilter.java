package com.example.demo.config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.demo.service.JWTService;
import com.example.demo.service.CreatorDetailsService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtFilter extends OncePerRequestFilter{   // once for every HTTP request

	@Autowired
	JWTService jwtService;   // handles creating, validating, and extracting data from JWTs
	
	@Autowired
	ApplicationContext context;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		Cookie[] cookies = request.getCookies();   // Gets cookies from the incoming request, "withCredentials"
		System.out.println("jwtfilter");
		if (cookies != null) {
			System.out.println("cookies");
            for (Cookie cookie : cookies) {
            	System.out.println(cookie.getName());
                if ("authToken".equals(cookie.getName())) {
                    String token = cookie.getValue();
                    System.out.println("cookie "+ token);
                    String email = jwtService.extractEmail(token);
                    System.out.println(email);
	
					if(email != null && SecurityContextHolder.getContext().getAuthentication() == null) {
						UserDetails userDetails = context.getBean(CreatorDetailsService.class).loadUserByUsername(email);  // get user from DB with this email
						if(jwtService.validateToken(token, userDetails)) {  // correct signature & not expired
							UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
							authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
							SecurityContextHolder.getContext().setAuthentication(authToken);  // add user as authenticated globally
						}
						else {
			                // Token is invalid or expired, clear the authentication context
			                SecurityContextHolder.clearContext();
			                // Remove the cookie
			                Cookie expiredCookie = new Cookie("authToken", null);
			                expiredCookie.setPath("/");
			                expiredCookie.setMaxAge(0);  // Delete immediately
			                response.addCookie(expiredCookie);  // Send back to browser
			            }
					}
                }
            }
		}
		filterChain.doFilter(request, response);	  // passes the request to the next filter/controller
	}

}
