package com.example.demo.controller;

import java.math.BigDecimal;
import java.util.HashMap;
//import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Socials;
import com.example.demo.dto.Video;
import com.example.demo.model.Creator;
import com.example.demo.model.CreatorLogin;
import com.example.demo.service.JWTService;
import com.example.demo.service.PaymentService;
import com.razorpay.RazorpayException;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.example.demo.service.CreatorService;

@RestController
@RequestMapping("/creator")
public class CreatorController {
	
	@Autowired
	private CreatorService creatorService;
	
	@Autowired
	private PaymentService paymentService;
	
	@Autowired
	private AuthenticationManager authenticationManager; 
	
	@Autowired
	JWTService jwtService; 
	
	@PostMapping("/register")
	public ResponseEntity<String> register(@RequestBody Creator creator) {
		return creatorService.register(creator);
	}
	
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody CreatorLogin creator, HttpServletResponse response) {
		
		// issues JWT token & set in HTTP-only cookie
		Authentication authentication= authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(creator.getEmail(), creator.getPassword()));
		if(authentication.isAuthenticated()) {
			Creator cc = creatorService.getCreatorByEmail(creator.getEmail());
			String token=jwtService.generateToken(creator.getEmail(), cc.getCreatorId());
			
			Cookie cookie = new Cookie("authToken", token);
	        cookie.setHttpOnly(true);  //  Not accessible by JS
	        cookie.setSecure(false); // Requires HTTPS
	        cookie.setPath("/");
	        cookie.setMaxAge(24 * 60 * 60); // 1 day in seconds
	        response.addCookie(cookie);
			System.out.println("token "+token);
			
			return new ResponseEntity<>(cc.getCreatorId().toString(), HttpStatus.OK);
		}
		return new ResponseEntity<>("Failed", HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletResponse response) {
        // Clear the authentication context
        SecurityContextHolder.clearContext();

        // Remove the authToken cookie
        Cookie cookie = new Cookie("authToken", null);
        cookie.setHttpOnly(true);
        cookie.setSecure(false); // Requires HTTPS
        cookie.setPath("/");
        cookie.setMaxAge(0); // Expire the cookie immediately
        response.addCookie(cookie);

        return new ResponseEntity<>("Logged out successfully", HttpStatus.OK);
    }
	
	@GetMapping("/check-auth")
	public ResponseEntity<String> checkAuth(HttpServletRequest request) {
	    Cookie[] cookies = request.getCookies();
		System.out.println("check auth");
		if (cookies != null) {
			System.out.println("auth cookies");
            for (Cookie cookie : cookies) {
            	System.out.println(cookie.getName());
                if ("authToken".equals(cookie.getName())) {
                	 return new ResponseEntity<>("Authenticated", HttpStatus.OK);
                }
            }
		}
		return new ResponseEntity<>("Not Authenticated", HttpStatus.UNAUTHORIZED);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Creator> getCreator(@PathVariable Integer id) {
		return new ResponseEntity<>(creatorService.getCreator(id), HttpStatus.OK);
	}
	
	@GetMapping("/{id}/videos")
	public ResponseEntity<List<Video>> getCreatorVideos(@PathVariable Integer id) {
		return creatorService.getCreatorVideos(id);
	}
	
	@PostMapping("/upload-video")
	public ResponseEntity<String> uploadVideo(@RequestBody Video video){
		return creatorService.uploadVideo(video);
	}
	
	@GetMapping("/{id}/socials")
	public ResponseEntity<Socials> getCreatorSocials(@PathVariable Integer id) {
		return creatorService.getCreatorSocials(id);
	}
	
	@DeleteMapping("/video/{id}")
	public ResponseEntity<String> deleteVideo(@PathVariable Integer id) {
		return creatorService.deleteVideo(id);
	  }
	
	@GetMapping("/analytics/{cId}/current-visits")
	public ResponseEntity<List<Object[]>> getCurrentVisits(@PathVariable Integer cId) {
		return creatorService.getCurrentVisits(cId);
	}
	
	@GetMapping("/analytics/{cId}/website-visits")
	public ResponseEntity<List<Long>> getWebsiteVisits(@PathVariable Integer cId) {
		return creatorService.getWebsiteVisits(cId);
	}
	
	@GetMapping("/analytics/{cId}/device-used")
	public ResponseEntity<List<Object[]>> getDevicesUsed(@PathVariable Integer cId) {
		return creatorService.getDevicesUsed(cId);
	}
	
	@GetMapping("/analytics/{cId}/latest-videos")
	public ResponseEntity<List<Video>> getLatestVideos(@PathVariable Integer cId){
		return creatorService.getLatestVideos(cId);
	  }
	
	@GetMapping("/analytics/trending-videos")
	public ResponseEntity<List<Video>> getTrendingVideos(){
		return creatorService.getTrendingVideos();
	  }
	
	@GetMapping("/analytics/trending-genres")
	public ResponseEntity<List<String>> getTrendingGenres(){
		return creatorService.getTrendingGenres();
	  }
	
	@GetMapping("/analytics/{cId}/age-gender")
	public ResponseEntity<Map<String, List<List<Integer>>>> getAgeGenderDistribution(@PathVariable Integer cId){
		return creatorService.getAgeGenderDistribution(cId);
	  }
	
//	@GetMapping("/{cId}/earnings")
//	public ResponseEntity<Double> getTotalEarnings(@PathVariable Integer cId) throws RazorpayException{
//		return  ResponseEntity.ok(paymentService.getTotalEarningsForCurrentMonth());
//	  }
	
//	@GetMapping("/analytics/{cId}/age-gender")
//	public ResponseEntity<HashMap<String, List<Integer>>> getUserAgeGender(@PathVariable Integer cId) {
//		return creatorService.getUserAgeGender(cId);
//	}
	
//	@PutMapping("/analytics/{cId}/age-gender/{age}/{gender}")
//	public ResponseEntity<String> updateUserAgeGender(@PathVariable Long cId, @PathVariable int age, @PathVariable String gender) {
//		return ResponseEntity.ok(creatorService.updateUserAgeGender(cId, age, gender));
//	}
	
//  Current visits => 
//	Device Used => 
//	Latest Videos => 
//  Website visits => 
//	Trending Videos => 
//	Trending Genres => 
//	Age & Gender Distribution =>
}

