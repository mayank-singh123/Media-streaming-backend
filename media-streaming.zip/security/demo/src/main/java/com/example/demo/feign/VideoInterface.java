package com.example.demo.feign;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.dto.Video;

@FeignClient("VIDEO-SERVICE")
public interface VideoInterface {
	@GetMapping("/creator/{id}/videos")
	public ResponseEntity<List<Video>> getCreatorVideos(@PathVariable Integer id);
	
	@PostMapping("/upload-video")
	public ResponseEntity<String> uploadVideo(@RequestBody Video video);
	
	@DeleteMapping("/video/{id}")
	public ResponseEntity<String> deleteVideo(@PathVariable Integer id);

	@GetMapping("/analytics/{cId}/current-visits")
	public ResponseEntity<List<Object[]>> getCurrentVisits(@PathVariable Integer cId);
	
	@GetMapping("/analytics/{cId}/website-visits")
	public ResponseEntity<List<Long>> getWebsiteVisits(@PathVariable Integer cId);
	
	@GetMapping("/analytics/{cId}/device-used")
	public ResponseEntity<List<Object[]>> getDevicesUsed(@PathVariable Integer cId);
	
	@GetMapping("/analytics/{cId}/latest-videos")
	public ResponseEntity<List<Video>> getLatestVideos(@PathVariable Integer cId);
	
	@GetMapping("/analytics/trending-videos")
	public ResponseEntity<List<Video>> getTrendingVideos();
	
	@GetMapping("/analytics/trending-genres")
	public ResponseEntity<List<String>> getTrendingGenres();
	
	@GetMapping("/analytics/{cId}/age-gender")
	public ResponseEntity<Map<String, List<List<Integer>>>> getAgeGenderDistribution(@PathVariable Integer cId);
}
