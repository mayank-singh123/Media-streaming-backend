package com.example.demo.repository;

//import java.util.HashMap;
//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
//import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.example.demo.dto.Socials;
import com.example.demo.model.Creator;


@Repository
public interface CreatorRepo extends JpaRepository<Creator, Integer> {
	Creator findByEmail(String email);
	
	@Query("SELECT c.socials FROM Creator c WHERE c.creatorId = :creatorId")
	Socials findSocialsByCreatorId(@Param("creatorId") Integer creatorId);
	
//	@Query("SELECT c.locations FROM Creator c WHERE c.creatorId = :creatorId")
//	HashMap<String, Long> findLocationsByCreatorId(@Param("creatorId") Long creatorId);
//	
//	@Query("SELECT c.devices FROM Creator c WHERE c.creatorId = :creatorId")
//	HashMap<String, Long> findDevicesByCreatorId(@Param("creatorId") Long creatorId);
//
//	@Query("SELECT c.distribution FROM Creator c WHERE c.creatorId = :creatorId")
//	HashMap<String, List<Integer>> findDistributionByCreatorId(Integer cId);
}
