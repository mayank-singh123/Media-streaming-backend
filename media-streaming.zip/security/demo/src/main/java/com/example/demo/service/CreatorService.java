package com.example.demo.service;

//import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.dto.Socials;
import com.example.demo.dto.Video;
import com.example.demo.feign.VideoInterface;
import com.example.demo.model.Creator;
import com.example.demo.repository.CreatorRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class CreatorService {
	@Autowired
	private CreatorRepo creatorRepo;
	
	@Autowired
	VideoInterface videoInterface;
	
	private BCryptPasswordEncoder encoder=new BCryptPasswordEncoder(12);  // no. of encryption rounds

	public ResponseEntity<String> register(Creator creator) {
		Creator creators=creatorRepo.findByEmail(creator.getEmail());
		if(creators==null) {
			creator.setPassword(encoder.encode(creator.getPassword()));
			creatorRepo.save(creator);
			return new ResponseEntity<String>("Creator Registered!", HttpStatus.OK);
		}
		return new ResponseEntity<String>("Creator already Registered with this email.", HttpStatus.BAD_REQUEST);
	}
	
	public ResponseEntity<List<Video>> getCreatorVideos(Integer id) {
		return videoInterface.getCreatorVideos(id);
	}
	
	public ResponseEntity<String> uploadVideo(Video video){
		return videoInterface.uploadVideo(video);
	}

	public Creator getCreatorByEmail(String email) {
		return creatorRepo.findByEmail(email);
	}

	public ResponseEntity<Socials> getCreatorSocials(Integer id) {
		return new ResponseEntity<Socials>(creatorRepo.findSocialsByCreatorId(id), HttpStatus.OK);
	}

	public ResponseEntity<String> deleteVideo(Integer id) {
		return videoInterface.deleteVideo(id);
	}
	
	
//	public String updateUserAgeGender(Long cId, int age, String gender) {
//		Creator creator = creatorRepo.findById(cId).get();	
//		HashMap<String, List<Integer>> distribution = creator.getDistribution();
//		List<Integer> ages = distribution.get(gender);
//		ages.add(age);
//		distribution.put(gender, ages);
//		creator.setDistribution(distribution);
//		creatorRepo.save(creator);
//		return "User Age Gender Updated";
//	}	

//	public ResponseEntity<HashMap<String, List<Integer>>> getUserAgeGender(Integer cId) {
//		return new ResponseEntity<HashMap<String, List<Integer>>>(creatorRepo.findDistributionByCreatorId(cId), HttpStatus.OK);
//	}

	public Creator getCreator(Integer id) {
		return creatorRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Creator not found with id: " + id)); 
	}

	public ResponseEntity<List<Object[]>> getCurrentVisits(Integer cId) {
		return videoInterface.getCurrentVisits(cId);
	}

	public ResponseEntity<List<Long>> getWebsiteVisits(Integer cId) {
		return videoInterface.getWebsiteVisits(cId);
	}

	public ResponseEntity<List<Object[]>> getDevicesUsed(Integer cId) {
		return videoInterface.getDevicesUsed(cId);
	}

	public ResponseEntity<List<Video>> getLatestVideos(Integer cId) {
		return videoInterface.getLatestVideos(cId);
	}

	public ResponseEntity<List<Video>> getTrendingVideos() {
		return videoInterface.getTrendingVideos();
	}

	public ResponseEntity<List<String>> getTrendingGenres() {
		return videoInterface.getTrendingGenres();
	}

	public ResponseEntity<Map<String, List<List<Integer>>>> getAgeGenderDistribution(Integer cId) {
		return videoInterface.getAgeGenderDistribution(cId);
	}
}

