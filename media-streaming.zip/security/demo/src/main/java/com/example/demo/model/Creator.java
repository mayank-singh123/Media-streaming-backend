package com.example.demo.model;

import java.util.ArrayList;
//import java.util.HashMap;
import java.util.List;

import com.example.demo.dto.Socials;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
//import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="creators")
public class Creator {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="creator_id")
	private Integer creatorId;
	
	private String name; 
	private String email;
	private Long phone;
	private String gender;
	private int age;
	private String avatar;
	private String password;
	
	private int totalEarnings = 0;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "socials_id", referencedColumnName = "socials_id")
    @JsonManagedReference
    private Socials socials;
	
	@ElementCollection
    private List<Integer> videoIds = new ArrayList<>(); 
}
