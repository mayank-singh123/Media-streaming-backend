package com.example.demo.service;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Base64;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class PaymentService {
//    @Value("${razorpay.api.key}")
    private String apiKey = "rzp_test_2EgeBnHlnBDdnr";

//    @Value("${razorpay.api.secret}")
    private String apiSecret = "X8hPUHwQZNADEzzFM4mh4Cvu";
    
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;  // json -> object

    public PaymentService(RestTemplate restTemplate, ObjectMapper objectMapper) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
    }

    public double getTotalEarningsForCurrentMonth() {
        try {
            long startOfMonth = new java.util.Date(java.time.LocalDate.now().withDayOfMonth(1)
                    .atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()).getTime() / 1000;

            long endOfMonth = new java.util.Date(java.time.LocalDate.now().withDayOfMonth(
                    java.time.YearMonth.now().lengthOfMonth()).atTime(23, 59, 59)
                    .atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()).getTime() / 1000;

            String url = "https://api.razorpay.com/v1/payments?from=" + startOfMonth + "&to=" + endOfMonth;

            // Basic Auth
            String auth = apiKey + ":" + apiSecret;
            String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
			
            System.out.println(url);
			System.out.println(auth);
			
            // Call Razorpay API
            String response = restTemplate.getForObject(url, String.class,
                    new HttpHeaders() {{
                        add("Authorization", "Basic " + encodedAuth);
                    }});

            JsonNode root = objectMapper.readTree(response);

            // Calculate total earnings
            double totalEarnings = 0;
            for (JsonNode payment : root.get("items")) {
                totalEarnings += payment.get("amount").asDouble();
            }
            
            System.out.println(totalEarnings);
            
            return totalEarnings / 100; // Convert from paise to INR
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}
