package com.example.demo.repo;

import org.springframework.stereotype.Repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Videos;

@Repository
public interface VideoRepo extends JpaRepository<Videos, Integer>{
	
	@Query(value = "SELECT * FROM videos WHERE category= :category ORDER BY RAND() LIMIT 10", nativeQuery = true)
	List<Videos> getCategory(String category);

	List<Videos> findByCreatorId(Integer id);
	
	@Query("SELECT v FROM Videos v JOIN v.favourites f WHERE f = :userEmail")
    List<Videos> findFavoriteVideosByUserEmail(String userEmail);

	@Query("SELECT v FROM Videos v " +
	           "ORDER BY SIZE(v.views) DESC")
	List<Videos> getAllVideosSortedByViews(Pageable pageable);
	
	@Query(value = "SELECT v.genre FROM Video v GROUP BY v.genre ORDER BY SUM(SIZE(v.views)) DESC", nativeQuery = true)
    List<String> getGenresByVideoVisits();
	
	List<Videos> findByCreatorIdOrderByReleaseDateDesc(Integer creatorId);  // may be it is a Date not string

}
