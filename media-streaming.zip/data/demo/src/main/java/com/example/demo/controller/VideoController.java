package com.example.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Cast;
import com.example.demo.dto.Comment;
import com.example.demo.dto.Image;
import com.example.demo.dto.Short;
import com.example.demo.dto.Viewer;
import com.example.demo.service.VideoService;
import com.example.demo.model.Videos;

@RestController
public class VideoController {
	@Autowired
    private VideoService videoService;
	
	@PostMapping("/upload-video")
	public ResponseEntity<String> uploadVideo(@RequestBody Videos video) {
		return ResponseEntity.ok(videoService.uploadVideo(video));
	}
	
	@GetMapping("/creator/{id}/videos")
	public ResponseEntity<List<Videos>> getCreatorVideos(@PathVariable Integer id){
		return ResponseEntity.ok(videoService.getCreatorVideos(id));
	  }

	@GetMapping("/video/category/{category}")
	public ResponseEntity<List<Videos>> getCategory(@PathVariable String category){
		return ResponseEntity.ok(videoService.getCategory(category));
	  }
	
	@GetMapping("/video/favourites/{userEmail}")
	public ResponseEntity<List<Videos>> getFavourites(@PathVariable String userEmail){
		return ResponseEntity.ok(videoService.getFavourites(userEmail));
	  }
	
	@GetMapping("/video/search/{query}")
	public ResponseEntity<List<Videos>> searchVideos(@PathVariable String query){
		return ResponseEntity.ok(videoService.searchVideos(query));
	  }

	@GetMapping("/video/{id}")
	public ResponseEntity<Videos> getVideo(@PathVariable Integer id) {
		return ResponseEntity.ok(videoService.getVideo(id));
	  }

	@GetMapping("/video/{id}/images")
	public ResponseEntity<List<Image>> getImages(@PathVariable Integer id) {
		return ResponseEntity.ok(videoService.getImages(id));
	}

	@GetMapping("/video/{id}/shorts")
	public ResponseEntity<List<Short>> getShorts(@PathVariable Integer id) {
		return ResponseEntity.ok(videoService.getShorts(id));
	}
	
	@GetMapping("/video/{id}/cast")
	public ResponseEntity<List<Cast>> getCast(@PathVariable Integer id) {
		return ResponseEntity.ok(videoService.getCast(id));
	}
	
	@PutMapping("/play/{vId}/watchtime")
	public ResponseEntity<String> updateWatchTime(@PathVariable Integer vId, @RequestBody Long watchTime) {
		return ResponseEntity.ok(videoService.updateWatchTime(vId, watchTime));
	}
	
	@PutMapping("/play/{vId}/update/{type}")
	public ResponseEntity<Videos> updateAnalyticsOfVideo(@PathVariable Integer vId, @PathVariable String type, @RequestBody String userEmail) {
		return ResponseEntity.ok(videoService.updateAnalyticsOfVideo(vId, type, userEmail));
	}
	
	@PutMapping("/play/{vId}/view")
	public ResponseEntity<Videos> addViewToVideo(@PathVariable Integer vId, @RequestBody Viewer viewer) {
		System.out.println("add view");
		return ResponseEntity.ok(videoService.addViewToVideo(vId, viewer));
	}
	
	@PutMapping("/play/{vId}/comment")
	public ResponseEntity<List<Comment>> addCommentToVideo(@PathVariable Integer vId, @RequestBody Comment comment) {
		return ResponseEntity.ok(videoService.addCommentToVideo(vId, comment));
	}
	
	@DeleteMapping("/video/{id}")
	public ResponseEntity<String> deleteVideo(@PathVariable Integer id) {
		return ResponseEntity.ok(videoService.deleteVideo(id));
	  }
	
	
	@GetMapping("/analytics/{cId}/current-visits")
	public ResponseEntity<List<Object[]>> getCurrentVisits(@PathVariable Integer cId) {
		return ResponseEntity.ok(videoService.getCurrentVisits(cId));
	}
	
	@GetMapping("/analytics/{cId}/website-visits")
	public ResponseEntity<List<Long>> getWebsiteVisits(@PathVariable Integer cId) {
		return ResponseEntity.ok(videoService.getWebsiteVisits(cId));
	}
	
	@GetMapping("/analytics/{cId}/device-used")
	public ResponseEntity<List<Object[]>> getDevicesUsed(@PathVariable Integer cId) {
		return ResponseEntity.ok(videoService.getDevicesUsed(cId));
	}
	
	@GetMapping("/analytics/{cId}/latest-videos")
	public ResponseEntity<List<Videos>> getLatestVideos(@PathVariable Integer cId){
		return ResponseEntity.ok(videoService.getLatestVideos(cId));
	  }
	
	@GetMapping("/analytics/trending-videos")
	public ResponseEntity<List<Videos>> getTrendingVideos(){
		return ResponseEntity.ok(videoService.getTrendingVideos());
	  }
	
	@GetMapping("/analytics/trending-genres")
	public ResponseEntity<List<String>> getTrendingGenres(){
		return ResponseEntity.ok(videoService.getTrendingGenres());
	  }
	
	@GetMapping("/analytics/{cId}/age-gender")
	public ResponseEntity<Map<String, List<List<Integer>>>> getAgeGenderDistribution(@PathVariable Integer cId){
		return ResponseEntity.ok(videoService.getAgeGenderDistribution(cId));
	  }
	
}
