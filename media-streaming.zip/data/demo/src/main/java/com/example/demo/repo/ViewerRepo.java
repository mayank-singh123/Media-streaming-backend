package com.example.demo.repo;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.dto.Viewer;

import feign.Param;

@Repository
public interface ViewerRepo extends JpaRepository<Viewer, Integer> {

	 @Query("SELECT v.location, COUNT(v) " +
	           "FROM Viewer v " +
	           "JOIN v.videos vid " +
	           "WHERE vid.creatorId = :creatorId " +
	           "GROUP BY v.location")
	    List<Object[]> findViewerCountsByLocation(@Param("creatorId") Integer creatorId);
    
	    @Query("SELECT MONTH(v.firstViewedDate), COUNT(v) " +
	    	       "FROM Viewer v " +
	    	       "JOIN v.videos vid " +
	    	       "WHERE vid.creatorId = :creatorId " +
	    	       "GROUP BY MONTH(v.firstViewedDate) " +
	    	       "ORDER BY MONTH(v.firstViewedDate)")
	    	List<Object[]> findViewerCountsByMonth(@Param("creatorId") Integer creatorId);
    
    @Query("SELECT v.device, COUNT(v) " +
            "FROM Viewer v JOIN v.videos vid " +
            "WHERE vid.creatorId = :creatorId " +
            "GROUP BY v.device")
     List<Object[]> findViewerCountsByDevices(@Param("creatorId") Integer creatorId);
    
     @Query("SELECT v.gender, v.age, COUNT(v) " +
             "FROM Viewer v " +
             "JOIN v.videos vid " +
             "WHERE vid.creatorId = :creatorId " +
             "GROUP BY v.gender, v.age")
      List<Object[]> findAgeGenderDistribution(@Param("creatorId") Integer creatorId);

     @Query("SELECT g, COUNT(v.viewerId) AS viewCount " +
             "FROM Viewer v " +
             "JOIN v.videos vid " +
             "JOIN vid.genres g " + 
             "GROUP BY g " +
             "ORDER BY viewCount DESC")
	List<Object[]> findTop5TrendingGenres(Pageable pageable);
}