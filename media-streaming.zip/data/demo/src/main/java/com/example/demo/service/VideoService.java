package com.example.demo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
//import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.dto.Cast;
import com.example.demo.dto.Comment;
import com.example.demo.dto.Image;
import com.example.demo.dto.Short;
import com.example.demo.dto.Viewer;
import com.example.demo.model.Videos;
import com.example.demo.repo.VideoRepo;
import com.example.demo.repo.ViewerRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class VideoService {
    @Autowired
    private VideoRepo videoRepo;
    
    @Autowired
    private ViewerRepo viewerRepo;

	public String uploadVideo(Videos video) {
		videoRepo.save(video);
        return "Video Uploaded";
	}

	public List<Videos> getCategory(String category) {   // get 10 random videos for trending, recommended, upcoming
		return videoRepo.getCategory(category);
	}

	public Videos getVideo(Integer id) {
		return videoRepo.findById(id) 
                .orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + id)); 
	}

	public List<Image> getImages(Integer id) {
		Videos video = videoRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + id)); 
		List<Image> imgs = video.getImages();
		return imgs;
	}

	public List<Short> getShorts(Integer id) {
		Videos video = videoRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + id)); 
		List<Short> videos = video.getShorts();
		return videos;
	}

	public List<Cast> getCast(Integer id) {
		Videos video = videoRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + id)); 
		List<Cast> cast = video.getCast();
		return cast;
	}
	
	public Videos updateAnalyticsOfVideo(Integer vId, String type, String userEmail) {  // like, favourite, view
		Videos video = videoRepo.findById(vId).orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + vId));
		switch (type) {
			case "like":
				List<String> likes = video.getLikes();
				if(likes.contains(userEmail)) {
					likes.removeIf(email -> (email.equalsIgnoreCase(userEmail)));	
				}
				else {
					likes.add(userEmail);
				}
				video.setLikes(likes);
				break;
//			case "view":
//				List<String> views = video.getViews();
//				if(!views.contains(userEmail)) {
//					views.add(userEmail);
//				}
//				video.setViews(views);
//				break;
				
			case "favourite":
				List<String> favourites = video.getFavourites();
				if(favourites.contains(userEmail)) {
					favourites.removeIf(email -> (email.equalsIgnoreCase(userEmail)));	
				}
				else {
					favourites.add(userEmail);
				}
				video.setFavourites(favourites);
				break;
		default:
			break;
		}
		return videoRepo.save(video);
	}

	public Videos addViewToVideo(Integer vId, Viewer viewer) {
		Videos video = videoRepo.findById(vId).orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + vId)); 
		if(!video.getViews().stream().anyMatch(obj -> obj.getEmail() == viewer.getEmail())) {  // add only one view at one video
			viewer.setVideos(video);
			video.getViews().add(viewer);	
			System.out.println("view added");
		}
		System.out.println("view already present");
		return videoRepo.save(video);
	}
	
	public List<Comment> addCommentToVideo(Integer vId, Comment comment) {
		Videos video = videoRepo.findById(vId).orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + vId)); 
		comment.setVideos(video);
	    video.getComments().add(comment);
	    videoRepo.save(video);
	    return video.getComments();
	}

	public List<Videos> getCreatorVideos(Integer id) {
		return videoRepo.findByCreatorId(id);
	}

	public String deleteVideo(Integer id) {
		Videos video = videoRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + id)); 
		if(video!=null) {
			videoRepo.deleteById(id);	
			return "Video Deleted";
		}
		return "Video not found";
	}

	public List<Videos> searchVideos(String query) {
		List<Videos> allVideos = videoRepo.findAll();
        String lowerCaseSearchTerm = query.toLowerCase();

        return allVideos.stream()
                .filter(video -> video.getTitle().toLowerCase().contains(lowerCaseSearchTerm) ||
                        video.getOverview().toLowerCase().contains(lowerCaseSearchTerm) ||
                        video.getGenres().stream().anyMatch(genre -> genre.toLowerCase().contains(lowerCaseSearchTerm)) ||
                        video.getCast().stream().anyMatch(cast -> cast.getName().toLowerCase().contains(lowerCaseSearchTerm) ||
                                cast.getCharacterr().toLowerCase().contains(lowerCaseSearchTerm)))
                .collect(Collectors.toList());
    }

	public List<Videos> getFavourites(String userEmail) {
		return videoRepo.findFavoriteVideosByUserEmail(userEmail);
	}

	public String updateWatchTime(Integer vId, Long watchTime) {
		Videos video = videoRepo.findById(vId).orElseThrow(() -> new EntityNotFoundException("Video not found with id: " + vId)); 
		if(video!=null && video.getTotalWatchTime()!=null) {
			Long currentWatchTime = video.getTotalWatchTime();
			video.setTotalWatchTime(currentWatchTime + watchTime);
			videoRepo.save(video);	
			return "Video WatchTime Updated";
		}
		return "Video not found";
	}

	public List<Videos> getLatestVideos(Integer cId) {
		return videoRepo.findByCreatorIdOrderByReleaseDateDesc(cId);
	}
	
	public List<Videos> getTrendingVideos() {
		return videoRepo.getAllVideosSortedByViews(PageRequest.of(0, 5));
	}

	public List<Object[]> getCurrentVisits(Integer cId) {
		return viewerRepo.findViewerCountsByLocation(cId);
	}

	public List<Long> getWebsiteVisits(Integer cId) {
		List<Object[]> rawData = viewerRepo.findViewerCountsByMonth(cId);
        List<Long> monthlyCounts = Arrays.asList(new Long[12]);
        for (Object[] row : rawData) {
            int monthIndex = ((Integer) row[0]) - 1;  // Convert to 0-based index
            monthlyCounts.set(monthIndex, (Long) row[1]); // Set actual count
        }
        return monthlyCounts;
	}

	public List<Object[]> getDevicesUsed(Integer cId) {
		return viewerRepo.findViewerCountsByDevices(cId);
	}

	public List<String> getTrendingGenres() {
		List<Object[]> rawData = viewerRepo.findTop5TrendingGenres(PageRequest.of(0, 5));

        return rawData.stream()
                      .map(obj -> (String) obj[0]) // Extract genre names
                      .collect(Collectors.toList());
//		return videoRepo.getGenresByVideoVisits();
	}

	public Map<String, List<List<Integer>>> getAgeGenderDistribution(Integer cId) {
		List<Object[]> rawData = viewerRepo.findAgeGenderDistribution(cId);

        Map<String, List<List<Integer>>> result = new HashMap<>();
        List<List<Integer>> maleData = new ArrayList<>();
        List<List<Integer>> femaleData = new ArrayList<>();

        for (Object[] row : rawData) {
            String gender = (String) row[0];
            Integer age = (Integer) row[1];
            Integer count = ((Number) row[2]).intValue(); // Convert Long to Integer safely

            List<Integer> ageCountPair = List.of(age, count);

            if ("Male".equalsIgnoreCase(gender)) {
                maleData.add(ageCountPair);
            } else if ("Female".equalsIgnoreCase(gender)) {
                femaleData.add(ageCountPair);
            }
        }

        result.put("male", maleData);
        result.put("female", femaleData);

        return result;
	}
}
