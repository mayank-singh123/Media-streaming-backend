package com.example.demo.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
//import java.util.HashMap;
//import java.util.Map;

import com.example.demo.dto.Cast;
import com.example.demo.dto.Comment;
import com.example.demo.dto.Image;

import com.example.demo.dto.Short;
import com.example.demo.dto.Viewer;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor 
@Entity
public class Videos {
	 	@Id
	 	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 	@Column(name="videos_id")
	    private Integer videosId;   // generate random id
	 	
	    private String title; 
	    
	    @Lob   // Large text data
	    @Column(columnDefinition = "TEXT")    // TEXT type in DB
	    private String overview; 
	    
	    private String posterPath;   // Thumbnail
	    
	    private String videoUrl;  // actual video
	    
	    private String releaseDate = new Date().toString(); 
	    
	    private float voteAverage = 0.0f; 
	    private int voteCount = 0; 
	    private String runtime; 
	    private String language;
	    
	    private Long totalWatchTime = 0L;  // in sec
	    
	    private String category;  // Popular, Upcoming, TopRated, NowPlaying, Trending
	    
	    private Integer creatorId;
	    
//	    cascade - Save/delete children automatically with parent
//	    orphanRemoval - Delete child if parent is deleted
	    @OneToMany(mappedBy = "videos", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	    @JsonManagedReference   // prevent infinite loops in JSON 
	    private List<Image> images = new ArrayList<Image>();
	    
	    @OneToMany(mappedBy = "videos", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	    @JsonManagedReference
	    private List<Short> shorts = new ArrayList<Short>();
	    
	    @OneToMany(mappedBy = "videos", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	    @JsonManagedReference
	    private List<Cast> cast = new ArrayList<Cast>();
	    
	    @ElementCollection   // List of primitive Data type
	    @CollectionTable(name = "videos_genres", joinColumns = @JoinColumn(name = "videos_id"))
	    @Column(name = "genre_id")
	    private List<String> genres = new ArrayList<String>();
	    
		@ElementCollection
	    @CollectionTable(name = "videos_likes", joinColumns = @JoinColumn(name = "videos_id"))
	    @Column(name = "likes_id")
		private List<String> likes = new ArrayList<String>();  // list of userEmails that likes this video
		
		@ElementCollection
		@CollectionTable(name = "videos_favourites", joinColumns = @JoinColumn(name = "videos_id"))
	    @Column(name = "favourites_id")
		private List<String> favourites = new ArrayList<String>();  // // list of userEmails that add to fav this video
		
		
		@OneToMany(mappedBy = "videos", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	    @JsonManagedReference
		private List<Viewer> views = new ArrayList<Viewer>(); // list of userEmails that views this video
															// list of users with DateTime
		
		@OneToMany(mappedBy = "videos", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	    @JsonManagedReference
	    private List<Comment> comments = new ArrayList<Comment>();
}



