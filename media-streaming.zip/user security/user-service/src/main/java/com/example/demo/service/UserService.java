package com.example.demo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.dto.Cast;
import com.example.demo.dto.Comment;
import com.example.demo.dto.Image;
import com.example.demo.dto.Short;
import com.example.demo.dto.Video;
import com.example.demo.dto.Viewer;
import com.example.demo.feign.VideoInterface;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepo;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@Service
public class UserService {
	@Autowired
	private UserRepo userRepo;
	
//	private String razorpayKey = "rzp_test_2EgeBnHlnBDdnr";
//
//	private String razorpaySecret = "X8hPUHwQZNADEzzFM4mh4Cvu";
	
//	@Value("${razorpay.key}")
//	private String razorpayKey;
//
//	@Value("${razorpay.secret}")
//	private String razorpaySecret;
	
	@Autowired
	VideoInterface videoInterface;
	
	private BCryptPasswordEncoder encoder=new BCryptPasswordEncoder(12);

	public ResponseEntity<String> register(@RequestBody User user) {
		System.out.println("reistering user");
		User users=userRepo.findByEmail(user.getEmail());
		System.out.println("find user by email");
		if(users==null) {
			System.out.println("user saved");
			user.setPassword(encoder.encode(user.getPassword()));
			userRepo.save(user);
			return new ResponseEntity<String>("User Registered!", HttpStatus.OK);
		}
		System.out.println(users.getEmail());
		return new ResponseEntity<String>("User already Registered with this email.", HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<List<Video>> getCategory(String category) {
		return videoInterface.getVideoByCategory(category);
	}

	public ResponseEntity<Video> getVideo(Integer id) {
		return videoInterface.getVideoById(id);
	}

	public ResponseEntity<List<Image>> getImages(Integer id) {
		return videoInterface.getImages(id);
	}

	public ResponseEntity<List<Short>> getShorts(Integer id) {
		return videoInterface.getShorts(id);
	}

	public ResponseEntity<List<Cast>> getCast(Integer id) {
		return videoInterface.getCast(id);
	}

	public ResponseEntity<Video> updateAnalyticsOfVideo(Integer vId, String type, String userEmail) {
		return videoInterface.updateAnalyticsOfVideo(vId, type, userEmail);
	}
	
	public ResponseEntity<Video> addViewToVideo(Integer vId, Viewer viewer) {
		return videoInterface.addViewToVideo(vId, viewer);
	}

	public ResponseEntity<List<Comment>> addCommentToVideo(Integer vId, Comment comment) {
		return videoInterface.addCommentToVideo(vId, comment);
	}

	public ResponseEntity<List<Video>> getCreatorVideos(Integer id) {
		return videoInterface.getCreatorVideos(id);
	}

	public ResponseEntity<List<Video>> searchVideos(String query) {
		return videoInterface.searchVideos(query);
	}

	public ResponseEntity<List<Video>> getFavourites(String userEmail) {
		return videoInterface.getFavourites(userEmail);
	}

//	public ResponseEntity<String> getSubscription(String receipt) throws RazorpayException {
//		RazorpayClient client = new RazorpayClient(razorpayKey, razorpaySecret);
//		JSONObject orderRequest = new JSONObject();
//		orderRequest.put("amount", (int) (500 * 100)); // Amount in paise
//		orderRequest.put("currency", "INR");
//		orderRequest.put("receipt", receipt);
//
//		Order order = client.orders.create(orderRequest); 
//		
//		System.out.println(order.get("id").toString());
//		
//		return new ResponseEntity<String>("Payment Successful", HttpStatus.ACCEPTED);
//	}

	public ResponseEntity<User> getUser(String email) {
		User users=userRepo.findByEmail(email);
		if(users!=null) {
			return new ResponseEntity<User>(users, HttpStatus.OK);			
		}
		return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<String> updateWatchTime(Integer vId, Long watchTime) {
		return videoInterface.updateWatchTime(vId, watchTime);
	}

//	public ResponseEntity<HashMap<String, List<List<Integer>>>> getAgeGenderAnalytics() {
//		List<Object[]> results = userRepo.getAgeGenderDistribution();
//		HashMap<String, List<List<Integer>>> distribution = new HashMap<String, List<List<Integer>>>();
//
//        for (Object[] row : results) {
//            int age = (int) row[0];
//            String gender = (String) row[1];
//            int count = ((Number) row[2]).intValue();
//
//            // Initialize list if gender key does not exist
//            distribution.computeIfAbsent(gender, k -> new ArrayList<>());
//
//            // Add age and count as a pair
//            distribution.get(gender).add(Arrays.asList(age, count));
//        }
//
//        return new ResponseEntity<HashMap<String, List<List<Integer>>>>(distribution, HttpStatus.ACCEPTED);
//	}
	
	
}
