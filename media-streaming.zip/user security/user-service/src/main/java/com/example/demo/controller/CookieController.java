package com.example.demo.controller;

import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/user")
public class CookieController {

    @PostMapping("/set")
    public String setCookie(@RequestParam String text, HttpServletResponse response) {
        Cookie cookie = new Cookie("mySecureCookie", text);
        cookie.setHttpOnly(true);
        cookie.setSecure(true); // Ensure this works over HTTPS
        cookie.setPath("/");
        cookie.setMaxAge(24 * 60 * 60); // 1 day in seconds

        response.addCookie(cookie);
        return "Cookie set successfully!";
    }

    @GetMapping("/get")
    public String getCookie(@CookieValue(value = "mySecureCookie", defaultValue = "No cookie") String cookieValue) {
        return cookieValue;
    }
}

