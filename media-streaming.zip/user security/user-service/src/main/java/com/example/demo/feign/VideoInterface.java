package com.example.demo.feign;

import com.example.demo.dto.Image;
import com.example.demo.dto.Short;
import com.example.demo.dto.Cast;
import com.example.demo.dto.Comment;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.Video;
import com.example.demo.dto.Viewer;

@FeignClient("VIDEO-SERVICE")
public interface VideoInterface {

	@GetMapping("/video/category/{category}")
	public ResponseEntity<List<Video>> getVideoByCategory(@PathVariable String category);
	
	@GetMapping("/video/favourites/{userEmail}")
	public ResponseEntity<List<Video>> getFavourites(@PathVariable String userEmail);
	
	@GetMapping("/video/genres")
	public ResponseEntity<List<Video>> getVideoByGenres(@RequestBody List<String> genres);

	@GetMapping("/video/{id}")
	public ResponseEntity<Video> getVideoById(@PathVariable Integer id);

	@GetMapping("/video/{id}/images")
	public ResponseEntity<List<Image>> getImages(@PathVariable Integer id);

	@GetMapping("/video/{id}/shorts")
	public ResponseEntity<List<Short>> getShorts(@PathVariable Integer id);
	
	@GetMapping("/video/{id}/cast")
	public ResponseEntity<List<Cast>> getCast(@PathVariable Integer id);
	
	@PutMapping("/play/{vId}/update/{type}")
	public ResponseEntity<Video> updateAnalyticsOfVideo(@PathVariable Integer vId, @PathVariable String type, @RequestBody String userEmail);
	
	@PutMapping("/play/{vId}/view")
	public ResponseEntity<Video> addViewToVideo(@PathVariable Integer vId, @RequestBody Viewer viewer);
	
	@PutMapping("/play/{vId}/comment")
	public ResponseEntity<List<Comment>> addCommentToVideo(@PathVariable Integer vId, @RequestBody Comment comment);
	
	@PutMapping("/play/{vId}/watchtime")
	public ResponseEntity<String> updateWatchTime(@PathVariable Integer vId, @RequestBody Long watchTime);
	
	@GetMapping("/creator/videos")
	public ResponseEntity<List<Video>> getCreatorVideos(@RequestParam Integer id);
	
	@GetMapping("/video/search/{query}")
	public ResponseEntity<List<Video>> searchVideos(@PathVariable String query);

}
