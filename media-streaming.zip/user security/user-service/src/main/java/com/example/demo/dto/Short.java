package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor 
public class Short {
	
	private String name;
	private String shortKey;
	private String type;  // 'Trailer', 'Teaser', 'Clip'
	
}
