package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor 
public class Socials {
	
	private String facebookId;
	private String instagramId;
	private String twitterId;
	private String imdbId;
	
}
