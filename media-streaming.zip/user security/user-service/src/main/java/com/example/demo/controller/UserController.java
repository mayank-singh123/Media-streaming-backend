package com.example.demo.controller;

//import java.util.HashMap;
//import java.util.Map;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Cast;
import com.example.demo.dto.Comment;
import com.example.demo.dto.Image;
import com.example.demo.dto.PaymentVerificationRequest;
import com.example.demo.dto.Short;
import com.example.demo.dto.Video;
import com.example.demo.dto.Viewer;
import com.example.demo.model.User;
import com.example.demo.model.UserLogin;
import com.example.demo.service.JWTService;
import com.example.demo.service.UserService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	
	@Autowired
	private AuthenticationManager authenticationManager; 
	
	@Autowired
	JWTService jwtService; 
	
//	private RazorpayClient razorpayClient;

//    public UserController() throws RazorpayException {
//        // Initialize Razorpay client with your API keys.  KEEP THESE SECURE!
//        this.razorpayClient = new RazorpayClient("rzp_test_2EgeBnHlnBDdnr", "X8hPUHwQZNADEzzFM4mh4Cvu");
//    }
	
	@PostMapping("/register")
	public ResponseEntity<String> register(@RequestBody User user) {
		return userService.register(user);
	}
	
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody UserLogin user, HttpServletResponse response) {
		
		Authentication authentication= authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
		if(authentication.isAuthenticated()) {
			String token=jwtService.generateToken(user.getEmail());
			
			Cookie cookie = new Cookie("userToken", token);
	        cookie.setHttpOnly(true);
	        cookie.setSecure(false); // Requires HTTPS
	        cookie.setPath("/");
	        cookie.setMaxAge(24 * 60 * 60); // 1 day in seconds
	        response.addCookie(cookie);
			System.out.println("token "+token);
	        return new ResponseEntity<>(user.getEmail(), HttpStatus.OK);		
	        }
		return new ResponseEntity<>("Failed", HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletResponse response) {
        // Clear the authentication context
        SecurityContextHolder.clearContext();
        
        Cookie cookie = new Cookie("userToken", null);
        cookie.setHttpOnly(true);
        cookie.setSecure(false); // Requires HTTPS
        cookie.setPath("/");
        cookie.setMaxAge(0); // Expire the cookie immediately
        response.addCookie(cookie);

        return new ResponseEntity<>("Logged out successfully", HttpStatus.OK);
    }
	
	@GetMapping("/check-auth")
	public ResponseEntity<String> checkAuth(HttpServletRequest request) {
		 Cookie[] cookies = request.getCookies();
			System.out.println("check auth");
			if (cookies != null) {
				System.out.println("auth cookies");
	            for (Cookie cookie : cookies) {
	            	System.out.println(cookie.getName());
	                if ("userToken".equals(cookie.getName())) {
	                	 return new ResponseEntity<>("Authenticated", HttpStatus.OK);
	                }
	            }
			}
			return new ResponseEntity<>("Not Authenticated", HttpStatus.UNAUTHORIZED);
	}
	
	@GetMapping("/get/{email}")
	public ResponseEntity<User> getUser(@PathVariable String email){
		return userService.getUser(email);
	  }
	
	@GetMapping("/video/category/{category}")
	public ResponseEntity<List<Video>> getCategory(@PathVariable String category){
		return userService.getCategory(category);
	  }
	
	@GetMapping("/video/favourites/{userEmail}")
	public ResponseEntity<List<Video>> getFavourites(@PathVariable String userEmail){
		return userService.getFavourites(userEmail);
	  }
	
	@GetMapping("/video/search/{query}")
	public ResponseEntity<List<Video>> searchVideos(@PathVariable String query){
		return userService.searchVideos(query);
	  }

	@GetMapping("/video/{id}")
	public ResponseEntity<Video> getVideo(@PathVariable Integer id) {
		return userService.getVideo(id);
	  }

	@GetMapping("/video/{id}/images")
	public ResponseEntity<List<Image>> getImages(@PathVariable Integer id) {
		return userService.getImages(id);
	}

	@GetMapping("/video/{id}/shorts")
	public ResponseEntity<List<Short>> getShorts(@PathVariable Integer id) {
		return userService.getShorts(id);
	}
	
	@GetMapping("/video/{id}/cast")
	public ResponseEntity<List<Cast>> getCast(@PathVariable Integer id) {
		return userService.getCast(id);
	}
	
	@PutMapping("/play/{vId}/update/{type}")
	public ResponseEntity<Video> updateAnalyticsOfVideo(@PathVariable Integer vId, @PathVariable String type, @RequestBody String userEmail) {
		return userService.updateAnalyticsOfVideo(vId, type, userEmail);
	}
	
	@PutMapping("/play/{vId}/view")
	public ResponseEntity<Video> addViewToVideo(@PathVariable Integer vId, @RequestBody Viewer viewer) {
		return userService.addViewToVideo(vId, viewer);
	}
	
	@PutMapping("/play/{vId}/comment")
	public ResponseEntity<List<Comment>> addCommentToVideo(@PathVariable Integer vId, @RequestBody Comment comment) {
		return userService.addCommentToVideo(vId, comment);
	}
	
	@PutMapping("/play/{vId}/watchtime")
	public ResponseEntity<String> updateWatchTime(@PathVariable Integer vId, @RequestBody Long watchTime) {
		return userService.updateWatchTime(vId, watchTime);
	}
	
//	@GetMapping("/creator/videos")
//	public ResponseEntity<List<Video>> getCreatorVideos(@RequestParam Integer id){
//		return userService.getCreatorVideos(id);
//	  }
	
//	@PostMapping("/payment")
//	public ResponseEntity<String> getSubscription(@RequestBody String receipt) throws RazorpayException {
//		return userService.getSubscription(receipt);
//	}
	
//	@GetMapping("/analytics/age-gender")
//	public ResponseEntity<HashMap<String, List<List<Integer>>>> getAgeGenderAnalytics(){
//		return userService.getAgeGenderAnalytics();
//	  }
	
	
//	@PostMapping("/create-order")
//    public ResponseEntity<String> createOrder() throws RazorpayException {
//        JSONObject options = new JSONObject();
//        options.put("amount", 500 * 100); // Amount in paise
//        options.put("currency", "INR");
//        options.put("receipt", "order_receipt_" + System.currentTimeMillis()); // Generate a unique receipt ID
//        options.put("notes", new JSONObject());  // Add any custom notes
//
//        Order order = razorpayClient.orders.create(options);
//        return ResponseEntity.ok(order.toString()); //Send order ID to frontend
//    }
//
//
//    @PostMapping("/verify-payment")
//    public ResponseEntity<String> verifyPayment(@RequestBody PaymentVerificationRequest request) throws RazorpayException{
//        try {
//        	System.out.println("verifyPayment");
//            JSONObject options = new JSONObject();
//            options.put("razorpay_order_id", request.getRazorpayOrderId());
//            options.put("razorpay_payment_id", request.getRazorpayPaymentId());
//            options.put("razorpay_signature", request.getRazorpaySignature());
//
////            boolean status = RazorpayClient.utility.verifyPaymentSignature(options);
//            boolean isValidSignature = Utils.verifyPaymentSignature(options, "X8hPUHwQZNADEzzFM4mh4Cvu"); // Use Utils and your secret key
//            System.out.println(isValidSignature);
//            if(isValidSignature){
//                return ResponseEntity.ok("Payment Verified");
//            }else{
//                return new ResponseEntity<>("Payment verification failed", HttpStatus.BAD_REQUEST);
//            }
//
//        } catch (RazorpayException e) {
//            return new ResponseEntity<>("Payment verification failed", HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
}
