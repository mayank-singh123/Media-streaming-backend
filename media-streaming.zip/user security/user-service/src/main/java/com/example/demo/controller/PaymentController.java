package com.example.demo.controller;

//import com.santosh.dto.UserDetailsDTO;
import com.example.demo.model.Payment;
import com.example.demo.service.PaymentService;
import org.springframework.web.bind.annotation.*;

//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/payments")
public class PaymentController {

  private final PaymentService paymentService;

  public PaymentController(PaymentService paymentService) {
      this.paymentService = paymentService;
  }

  // Create Payment Order
  @PostMapping("/create")
  public Map<String, Object> createOrder(@RequestBody Map<String, Object> request) throws Exception {
//      Double amount = extractDouble(request.get("amount"));
      String receipt = (String) request.get("receipt");
//      String eventName = (String) request.get("eventName");
//      String userIdString = (String) request.get("userId"); // Retrieve as String
//      Long userId = Long.valueOf(userIdString);             // Convert to Long

      return paymentService.createOrderWithUserDetails(receipt);
  }

  // Update Payment
//  @PostMapping("/update")
//  public String updatePayment(@RequestBody Map<String, Object> paymentDetails) {
//      String orderId = (String) paymentDetails.get("orderId");
//      String paymentId = (String) paymentDetails.get("paymentId");
//      String status = (String) paymentDetails.get("status");
//
//      // User Details for the update
//      UserDetailsDTO userDetailsDTO = new UserDetailsDTO();
//      userDetailsDTO.setName((String) paymentDetails.get("name"));
//      userDetailsDTO.setEmail((String) paymentDetails.get("email"));
//      userDetailsDTO.setContactNumber((String) paymentDetails.get("contactNumber"));
//      userDetailsDTO.setNumberOfTickets((Integer) paymentDetails.get("numberOfTickets"));
//      userDetailsDTO.setUserId((String) paymentDetails.get("userId"));
//      userDetailsDTO.setEventName((String) paymentDetails.get("eventName"));
//      userDetailsDTO.setAmount(extractDouble(paymentDetails.get("amount")));
////      userDetailsDTO.setDate((String) paymentDetails.get("date"));
////    Parse amount
////    Object amountObject = paymentDetails.get("amount");
////    Double amount = (amountObject instanceof Integer) ? Double.valueOf((Integer) amountObject) : (Double) amountObject;
////    userDetailsDTO.setAmount(amount);
//
//    // Parse date
//    Object dateObject = paymentDetails.get("date");
//    if (dateObject != null && dateObject instanceof String) {
//        try {
//            LocalDateTime date = LocalDateTime.parse((String) dateObject, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
//            userDetailsDTO.setDate(date);
//        } catch (DateTimeParseException e) {
//            throw new IllegalArgumentException("Invalid date format. Expected yyyy-MM-dd'T'HH:mm:ss", e);
//        }
//    }
//
//      paymentService.updatePayment(orderId, paymentId, status, userDetailsDTO);
//
//      return "Payment updated successfully!";
//  }

//  private Double extractDouble(Object value) {
//      return value instanceof Integer ? ((Integer) value).doubleValue() : (Double) value;
//  }
  @GetMapping("/customers")
  public List<Payment> getAllPaymentsWithUserDetails() {
      return paymentService.getAllPayments();
  }
}
