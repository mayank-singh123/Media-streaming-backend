package com.example.demo.service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.example.demo.model.Payment;
//import com.santosh.dto.UserDetailsDTO;
//import com.santosh.feign.UserDetailsClient;
import com.example.demo.repository.PaymentRepo;
import org.json.JSONObject;
//import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PaymentService {

	private final PaymentRepo paymentRepo;
//	private final UserDetailsClient userDetailsClient;
//	@Value("${razorpay.key}")
	private String razorpayKey = "rzp_test_2EgeBnHlnBDdnr";
//
//	@Value("${razorpay.secret}")
	private String razorpaySecret = "X8hPUHwQZNADEzzFM4mh4Cvu";

	public PaymentService(PaymentRepo paymentRepo) {
		this.paymentRepo = paymentRepo;
//		this.userDetailsClient = userDetailsClient;
	}

	public Map<String, Object> createOrderWithUserDetails(String receipt) throws Exception {
		// Create Razorpay order
		RazorpayClient client = new RazorpayClient(razorpayKey, razorpaySecret);
		JSONObject orderRequest = new JSONObject();
		orderRequest.put("amount", (int) (500 * 100)); // Amount in paise
		orderRequest.put("currency", "INR");
		orderRequest.put("receipt", receipt);

		Order order = client.orders.create(orderRequest);   // ---------------------------------------------------------------

		// Fetch user details from the User Details Microservice
//		UserDetailsDTO userDetailsDTO = userDetailsClient.getUserDetailsById(userId);
//		if (userDetailsDTO == null) {
//			throw new IllegalArgumentException("User details not found for userId: " + userId);
//		}
//
//		// Save payment data
//		Payment payment = new Payment();
//		payment.setAmount(amount);
//		payment.setReceipt(receipt);
//		payment.setEventName(eventName);
//		payment.setRazorpayOrderId(order.get("id"));
//		payment.setUserDetailsId(userDetailsDTO.getId());
//		paymentRepo.save(payment);

		// Prepare response
		Map<String, Object> response = new HashMap<>();
		response.put("orderId", order.get("id"));
		response.put("amount", 500);
		response.put("currency", "INR");
		return response;
	}

//	public void updatePayment(String orderId, String paymentId, String status, UserDetailsDTO userDetailsDTO) {
//		Payment payment = paymentRepo.findByRazorpayOrderId(orderId)
//				.orElseThrow(() -> new IllegalArgumentException("Invalid order ID"));
//
//		payment.setRazorpayPaymentId(paymentId);
//		payment.setStatus(status);
//		paymentRepo.save(payment);
//
//		// Update user details via UserDetailsClient if payment succeeds
//		if ("success".equalsIgnoreCase(status)) {
//			userDetailsClient.saveUserDetails(userDetailsDTO);
//		}
//	}
	public List<Payment> getAllPayments() {
      return paymentRepo.findAll(); // Uses JPA's default behavior to fetch relationships
  }
}