package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.dto.Socials;
import com.example.demo.dto.Video;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Creator {
	
	private String name; 
	private String email;
	private Long phone;
	private String gender;
	private int age;
	private String avatar;
	private String password;
	
	private int totalEarnings = 0;
	
    private Socials socials;
	
    private List<Video> videos = new ArrayList<Video>();
}
