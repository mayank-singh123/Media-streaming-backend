package com.example.demo.controller;

//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

//@CrossOrigin(origins = "http://localhost:3000")  // allow other url's to access these resources
@RestController
public class HelloController {

	@GetMapping("hello")
	public String greet(HttpServletRequest req) {
		System.out.println(req.getRequestedSessionId());
		return "Hello World "+req.getSession().getId();
	}
}
