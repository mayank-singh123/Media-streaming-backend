//package com.example.service;
//
//import java.util.List;
//
////import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.model.ChatGroup;
//import com.example.model.Message;
//import com.example.repository.ChatMessageRepository;
//
//@Service
//public class ChatService {
//    @Autowired
//    private ChatMessageRepository chatMessageRepository;
//
////    public ChatGroup saveMessage(ChatGroup message) {
////        return chatMessageRepository.save(message);
////    }
////
////    public List<ChatGroup> getMessagesByStreamId(Long streamId) {
////        return chatMessageRepository.findByStreamId(streamId);
////    }
//
//	public ChatGroup getMessages(Long gId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public ChatGroup sendMessage(Long gId, Message msg) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public ChatGroup editMessage(Long gId, Long mId, Message msg) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public ChatGroup deleteMessage(Long gId, Long mId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public ChatGroup replyMessage(Long gId, Long mId, Message msg) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public List<String> getGroups(Long id) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public ChatGroup createGroup(Long id, String title, List<Long> users) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public ChatGroup joinGroup(Long id, Long gId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public String leaveGroup(Long id, Long gId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//}
//
