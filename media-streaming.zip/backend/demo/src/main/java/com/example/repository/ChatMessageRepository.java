//package com.example.repository;
//
//import java.util.List;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.example.model.ChatGroup;
//
//public interface ChatMessageRepository extends JpaRepository<ChatGroup, Long> {
//	List<ChatGroup> findByStreamId(Long streamId);
//}
//
