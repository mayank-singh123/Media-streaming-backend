//package com.example.controller;
//
////import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
////import org.springframework.messaging.handler.annotation.MessageMapping;
////import org.springframework.messaging.handler.annotation.SendTo;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.model.ChatGroup;
//import com.example.model.Message;
//import com.example.service.ChatService;
//
//@RestController
//@RequestMapping("/chat")
//public class ChatController {
//    @Autowired
//    private ChatService chatService;
//
////    @MessageMapping("/sendMessage")
////    @SendTo("/topic/messages")
////    public ChatGroup sendMessage(ChatGroup chatMessage) {
////        return chatService.saveMessage(chatMessage);
////    }
//
//    @GetMapping("/{gId}")
//    public ResponseEntity<ChatGroup> getMessages(@PathVariable Long gId) {
//        return ResponseEntity.ok(chatService.getMessages(gId));
//    }
//    
//    @PostMapping("/{gId}/send}")
//    public ResponseEntity<ChatGroup> sendMessage(@PathVariable Long gId, @RequestBody Message msg) {
//        return ResponseEntity.ok(chatService.sendMessage(gId, msg));
//    }
//    
//    @PutMapping("/{gId}/edit/{mId}")
//    public ResponseEntity<ChatGroup> editMessage(@PathVariable Long gId, @PathVariable Long mId, @RequestBody Message msg) {
//        return ResponseEntity.ok(chatService.editMessage(gId, mId, msg));
//    }
//    
//    @DeleteMapping("/{gId}/delete/{mId}")
//    public ResponseEntity<ChatGroup> deleteMessage(@PathVariable Long gId, @PathVariable Long mId) {
//        return ResponseEntity.ok(chatService.deleteMessage(gId, mId));
//    }
//    
//    @PostMapping("/{gId}/reply/{mId}")
//    public ResponseEntity<ChatGroup> replyMessage(@PathVariable Long gId, @PathVariable Long mId, @RequestBody Message msg) {
//        return ResponseEntity.ok(chatService.replyMessage(gId, mId, msg));
//    }
//}
//
///**
//
///sendMsg/ - message
//
//get group messages
//user send msg
//user reply to msg
//user edit msg
//user delete msg
//
//
//**/