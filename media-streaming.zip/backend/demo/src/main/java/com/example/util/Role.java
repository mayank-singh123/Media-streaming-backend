package com.example.util;

public enum Role {
	USER,
    CREATOR
}
