//package com.example.model;
//
//import java.time.LocalDateTime;
//import java.util.List;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
//@Table(name = "message")
//public class Message {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;  // message id
//    private LocalDateTime timestamp;
//    private String msg;   // (text, video url, img)
// 
//    private Long user_id;   // one user -> many msgs
//    private Long group_id;  // group id -> msg id
//    
//    private List<Long> replies;  // [ msg IDs ]   while !replies.isEmpty() => refer each message
//    
//}
//
