//package com.example.model;
//
//import java.time.LocalDateTime;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Value;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
//@Table(name = "video-filter")
//public class VideoFilter {
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;
//	
//	@Value("")
//	private String title;
//	
//	@Value("")
//	private String description;
//	
//	@Value("")
//	private List<String> categories;
//	
//	@Value("")
//	private List<String> cast;  // director, actors
//	
//	@Value("")
//	private LocalDateTime duration;   // range
//	
//}
//
