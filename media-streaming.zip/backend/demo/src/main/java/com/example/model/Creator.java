package com.example.model;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;

//import java.time.LocalDateTime;
//import java.util.HashMap;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Value;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "creators")
public class Creator {
    @Id
    @Column(name = "creator_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String password;
//    private String email;
//    private Long phone;
//	  private int age;
    
//    @Value("")
//    private List<Long> videos;  // only for creators, [ video ids ]
    
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "creator_roles", 
        joinColumns = @JoinColumn(name = "creator_id"), 
        inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();
   
// chat, videos, streams - get/post/put/delete
}

