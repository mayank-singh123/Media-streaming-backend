package com.example.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.model.AppUser;
import com.example.model.UserLogin;
import com.example.repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepo;

//    public AppUser saveUser(AppUser user) {
//    	System.out.println("saveUser");
//    	String password=new BCryptPasswordEncoder().encode(user.getPassword());
//    	System.out.println(password);
//        user.setPassword(password);
//        return userRepository.save(user);
//    }

//    public AppUser findByUsername(String username) {
//    	System.out.println("findByUsername");
//        return userRepo.findByUsername(username);
//    }
//    
//    public UserDetails loadUserByUsername(String userName) {
//    	AppUser user = userRepo.findByUsername(userName);
//		if(user == null) {
//			throw new UsernameNotFoundException("User 404");
//		}
//		
//		
//		return new UserDetailsServiceImpl(user);
//	}

	public AppUser registerUser(AppUser user) {
		String password=new BCryptPasswordEncoder().encode(user.getPassword());
    	System.out.println(password);
        user.setPassword(password);
        return userRepo.save(user);
	}

	public AppUser loginUser(UserLogin user) {
		// TODO Auto-generated method stub
		return null;
	}

	public AppUser getUser(Long id) {
		return userRepo.findById(id).get();
	}

	public AppUser deleteUser(AppUser user) {
		// TODO Auto-generated method stub
		return null;
	}

	public String logoutUser() {
		// TODO Auto-generated method stub
		return null;
	}

	public String deleteUser(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

//	public AppUser updateUser(Long id, AppUser user) {
//		// TODO Auto-generated method stub
//		AppUser currUser=userRepo.findById(id).get();
//		if(currUser!=null) {
//			currUser.setUsername(user.getUsername());
//			currUser.setEmail(user.getEmail());
//			currUser.setPhone(user.getPhone());
//			currUser.setAccountType(user.getAccountType());
////			currUser.setMovieCategories(user.getMovieCategories());
//			return userRepo.save(currUser);
//		}
//		return null;
//	}

	public String resetUserPassword(Long id, UserLogin user) {
		// TODO Auto-generated method stub
		AppUser currUser=userRepo.findById(id).get();
		if(currUser!=null) {
			currUser.setPassword(user.getPassword());
			return "Password Reset Successfully!!";
		}
		return null;
	}

	public String logoutUser(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

//	public AppUser getFriends(Long id, AppUser user) {
//		// TODO Auto-generated method stub
//		return userRepo.findbyFriendsLists();
//	}

	public AppUser addFriend(Long id, Long fId, AppUser user) {
		// TODO Auto-generated method stub
		return null;
	}

	public String removeFriend(Long id, Long fId, AppUser user) {
		// TODO Auto-generated method stub
		return null;
	}

	public AppUser addToFavourites(Long id, Long pId, AppUser user) {
		// TODO Auto-generated method stub
		return null;
	}

	public String removeFromFavourites(Long id, Long pId, AppUser user) {
		// TODO Auto-generated method stub
		return null;
	}

	public AppUser getWatchHistory(Long id, AppUser user) {
		// TODO Auto-generated method stub
		return null;
	}

	public HashMap<Long, List<Long>> shareWithFriends(Long id, Long vId, List<Long> friendsLists) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<HashMap<Long, LocalDateTime>> addToBookmarks(Long id, Long vId, LocalDateTime timestamp) {
		// TODO Auto-generated method stub
		return null;
	}

	public String removeFromBookmarks(Long id, Long vId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<HashMap<Long, LocalDateTime>> getBookmarks(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}

