package com.example.util;

import java.io.IOException;

import org.springframework.stereotype.Component;

@Component
public class VideoTranscoder {
    public void transcodeVideo(String inputFilePath, String outputFilePath) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                "ffmpeg", "-i", inputFilePath, "-codec:v", "libx264", "-profile:v", "high", "-crf", "20", "-preset", "fast", outputFilePath
            );
            Process process = processBuilder.start();
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

