//package com.example.model;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Value;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
//@Table(name = "userProfile")
//public class UserProfile {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//    private String username;
//    private Long phone;
//	private int age;
//    private String accountType;  // user or creator
//    
//    @Value("")
//    private List<String> movieCategories; // (multiple)
//    
//    @Value("")
//    private List<String> friendsLists;
//    
//    @Value("")
//    private List<String> groups;
//    
//}
//
