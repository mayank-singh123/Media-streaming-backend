package com.example.service;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//
//import com.example.model.AppUser;
//import com.example.repository.UserRepository;

import org.springframework.stereotype.Service;

import com.example.model.Creator;
import com.example.repository.CreatorRepository;

//import com.example.model.Video;

@Service
public class CreatorService {
	
	@Autowired
    private CreatorRepository creatorRepo;
	
//	public List<Video> getVideos(Long id) {
//		// TODO Auto-generated method stub
//		return null;
//	}
	
//	@Autowired
//    private UserRepository userRepository;
//
//    public AppUser saveUser(AppUser user) {
//    	System.out.println("saveUser");
//    	String password=new BCryptPasswordEncoder().encode(user.getPassword());
//    	System.out.println(password);
//        user.setPassword(password);
//        return userRepository.save(user);
//    }
//
//    public AppUser findByUsername(String username) {
//    	System.out.println("findByUsername");
//        return userRepository.findByUsername(username);
//    }

//	public Video uploadVideo(Long id, Video video) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	public String removeVideo(Long id, Long vId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Creator registerCreator(Creator creator) {
		String password=new BCryptPasswordEncoder().encode(creator.getPassword());
    	System.out.println(password);
    	creator.setPassword(password);
        return creatorRepo.save(creator);
	}

	public Creator getCreator(Long id) {
		return creatorRepo.findById(id).get();
	}
}
