package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.autoconfigure.domain.EntityScan;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

//@EntityScan("com.example.model")
//@ComponentScan(basePackages={"com.example.repository","com.example.controller","com.example.model","com.example.service","com.example.util"})
//@EnableJpaRepositories("com.example.repository")
@SpringBootApplication
public class OnlineStreamingPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineStreamingPlatformApplication.class, args);
	}

}

/**

- `GET /users/watchlist` - Get user watchlist
- `POST /users/watchlist` - Add to watchlist
- `DELETE /users/watchlist/{videoId}` - Remove from watchlist
- `GET /users/history` - Get user streaming history


- `POST /videos/upload` - Upload video (Admin only)
- `GET /videos/{id}` - Get video details
- `GET /videos/stream/{id}` - Stream video (batch packets for users)
- `POST /videos/live/create` - Create live stream (Admin only)
- `GET /videos/search` - Search videos by title, genre, or language


- `GET /chat/connect` - Connect to chat service
- `POST /chat/send` - Send message
- `GET /chat/rooms/{id}/messages` - Get chat history for a room
(DMs and Group chats)



Login & SignUp Page:- (Multi-Step Form)

User name, Phone, Age, Account Type, Movie Categories (multiple), @FriendsLists, @Groups (open), Password, Email


User Profile Page:-

	1. Activity Dashboard - Watch History, Stats
	5. All Friends/Connections List
	
	2. Recommendations Section - Recommended Videos, Continue Watching, Content by Friends
	3. Watchlist - drag-and-drop lists, “Recommend to Friends” button - (share list)


Video Component:-
	1. Video Player - Video, Total views, similar videos, Comments, Likes, Dislikes, Share, Description
	2. Batch processing
	3. Search / Filter, Sort (UI)

Chat Page:-
	Groups:-  (any user can enroll / join in any group)
			i. Individual Video Comments (default, auto) - reply
			ii. Channel wise, Category wise, Director wise, Actor wise  (Auto)
			iii. Custom Friends/Family (manual)
			
			
Admin / Creator Profile Page:-
	1. Upload Videos - POST/id, UPDATE/id, GET/list?search=tags
	2. Create Live Streams - (live only) 
	3. Videos Analytics - total views, watchtime, likes, dislikes, shares, comments, 

 
 (login/sign-up)
 Home/Videos page -> if login, video detail page -> if paid, full video chunks player page (video player, desc, comments, random videos)
 									   			 -> else, redirect to subscription/payment page -> ^
 				  -> else, redirect to login/sign-up page -> ^
 Chat page -> only 1 creator create 1 chat group -> user/subscriber search & join the groups -> ping stream link -> redirect to stream page (hidden roomId pass)
 Streaming page -> only group members can join the creator live streams
 Profile/Dashboard page -> user -> Hoverable box (username, paid/new, logout) - /Favourites list (last watched), 
 						-> creator -> Videos Analytics (total views, watchtime, likes, dislikes, shares), Upload Videos, Create Live Streams
 
 
 
----------------------------------
security auth routes - user/creator
angular tv/movies - tmdb/mysql    (header/footer/menu same in all microservices/routes)
react streaming zegocloud
react profile page/dashboard, - videos, stream, chat, analytics, 

payment options
react chat/groups - firebase
spring boot video chunks player
microservices users/creators

AWS cloud deploy
documentation, testing
--------------------------------



**/

