package com.example.controller;

import java.util.Collection;
//import java.time.LocalDateTime;
//import java.util.HashMap;
//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Creator;
import com.example.service.CreatorDetailsService;
//import com.example.model.AppUser;
//import com.example.model.ChatGroup;
//import com.example.model.Video;
import com.example.service.CreatorService;
//import com.example.service.UserService;
import com.example.service.JWTService;

@RestController
@RequestMapping("/creator")
public class CreatorController {
	 @Autowired
	    private CreatorService creatorService;
	 
	 @Autowired
		AuthenticationManager authenticationManager;
		
		@Autowired
		JWTService jwtService; 
		
		@Autowired
	    private CreatorDetailsService creatorDetailsService;
		
	    // User Authentication
	    
	    @PostMapping("/register")
	    public ResponseEntity<Creator> registerUser(@RequestBody Creator creator) {
	        return ResponseEntity.ok(creatorService.registerCreator(creator));
	    }
	    
	    @PostMapping("/login")
	    public ResponseEntity<String> loginUser(@RequestBody Creator creator) {
	    	Authentication authentication= authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(creator.getUsername(), creator.getPassword()));
			if(authentication.isAuthenticated()) {
				
				UserDetails userDetails = creatorDetailsService.loadUserByUsername(creator.getUsername());
				Collection<? extends GrantedAuthority> authorities = userDetails.getAuthorities();
				
				String token=jwtService.generateToken(creator.getUsername(), "creator", authorities);
				System.out.print("token "+ token);
				return ResponseEntity.ok(token);
			}
			System.out.print("failed");
			return ResponseEntity.ok("Failed");
	    }
	    
	    @GetMapping("/get/{id}")
	    public ResponseEntity<Creator> getUser(@PathVariable Long id) {
	    	return ResponseEntity.ok(creatorService.getCreator(id));
	    }
	    
//	    @PostMapping("/logout/{id}")
//	    public ResponseEntity<String> logoutUser(@PathVariable Long id) {
//	        return ResponseEntity.ok(creatorService.logoutUser(id));
//	    }
//	    
//	    @PutMapping("/reset/{id}")
//	    public ResponseEntity<String> resetUserPassword(@PathVariable Long id, @RequestBody UserLogin user) {
//	        return ResponseEntity.ok(creatorService.resetUserPassword(id, user));
//	    }
	    
//	    @PutMapping("/update/{id}")
//	    public ResponseEntity<AppUser> updateUser(@PathVariable Long id, @RequestBody AppUser user) {
//	        return ResponseEntity.ok(userService.updateUser(id, user));
//	    }
	    
//	    
//	    @DeleteMapping("/delete/{id}")
//	    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
//	        return ResponseEntity.ok(creatorService.deleteUser(id));
//	    }

//	    @PostMapping("/register")
//	    public ResponseEntity<AppUser> registerUser(@RequestBody AppUser user) {
//	    	System.out.println("registerUser");
//	        return ResponseEntity.ok(creatorService.saveUser(user));
//	    }
	 
	    @GetMapping("/{id}/videos")
//	    public ResponseEntity<List<Video>> getVideos(@PathVariable Long id) {
//	        return ResponseEntity.ok(creatorService.getVideos(id));
//	    }
	    
	    @PostMapping("/{id}/upload-video") 
//	    public ResponseEntity<Video> uploadVideo(@PathVariable Long id, @RequestBody Video video) {
//	        return ResponseEntity.ok(creatorService.uploadVideo(id, video));
//	    }
	    
	    @DeleteMapping("/{id}/remove-video/{vId}")
	    public ResponseEntity<String> removeVideo(@PathVariable Long id, @PathVariable Long vId) {
	        return ResponseEntity.ok(creatorService.removeVideo(id, vId));
	    }
	    
}

// Upload Videos - POST/id, UPDATE/id, GET/list?search=tags
