//package com.example.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.model.Video;
//import com.example.model.VideoFilter;
//import com.example.repository.VideoRepository;
//
//@Service
//public class VideoService {
//    @Autowired
//    private VideoRepository videoRepository;
//
//    public Video saveVideo(Video video) {
//        return videoRepository.save(video);
//    }
//
//    public List<Video> getAllVideos() {
//        return videoRepository.findAll();
//    }
//
//	public Video getVideo(Long id) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public List<Video> filterVideos(VideoFilter filters) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//}
//
