package com.example.controller;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.AppUser;
//import com.example.model.ChatGroup;
import com.example.model.UserLogin;
import com.example.service.AppUserDetailsService;
//import com.example.service.ChatService;
import com.example.service.JWTService;
import com.example.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

//    @Autowired
//    private ChatService chatService;
    
    @Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	JWTService jwtService; 
	
	@Autowired
    private AppUserDetailsService appUserDetailsService;
	
    // User Authentication
    
    @PostMapping("/register")
    public ResponseEntity<AppUser> registerUser(@RequestBody AppUser user) {
        return ResponseEntity.ok(userService.registerUser(user));
    }
    
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody AppUser user) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword())
            );

            if (authentication.isAuthenticated()) {
                UserDetails userDetails = appUserDetailsService.loadUserByUsername(user.getUsername());
                String token = jwtService.generateToken(userDetails.getUsername(), "user", userDetails.getAuthorities());
                return ResponseEntity.ok(token);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Username or Password");
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication Failed");
    }
    
    @GetMapping("/get/{id}")
    public ResponseEntity<AppUser> getUser(@PathVariable Long id) {
    	return ResponseEntity.ok(userService.getUser(id));
    }
    
    @PostMapping("/logout/{id}")
    public ResponseEntity<String> logoutUser(@PathVariable Long id) {
        return ResponseEntity.ok(userService.logoutUser(id));
    }
    
    @PutMapping("/reset/{id}")
    public ResponseEntity<String> resetUserPassword(@PathVariable Long id, @RequestBody UserLogin user) {
        return ResponseEntity.ok(userService.resetUserPassword(id, user));
    }
    
//    @PutMapping("/update/{id}")
//    public ResponseEntity<AppUser> updateUser(@PathVariable Long id, @RequestBody AppUser user) {
//        return ResponseEntity.ok(userService.updateUser(id, user));
//    }
    
    
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        return ResponseEntity.ok(userService.deleteUser(id));
    }
    
    
    //   User Profile Page
    
//    @GetMapping("/{id}/friends")
//    public ResponseEntity<AppUser> getFriends(@PathVariable Long id, @RequestBody AppUser user) {
//        return ResponseEntity.ok(userService.getFriends(id, user));
//    }
    @PutMapping("/{id}/add-friend/{fId}")
    public ResponseEntity<AppUser> addFriend(@PathVariable Long id, @PathVariable Long fId, @RequestBody AppUser user) {
        return ResponseEntity.ok(userService.addFriend(id, fId, user));
    }
    @DeleteMapping("/{id}/remove-friend/{fId}")
    public ResponseEntity<String> removeFriend(@PathVariable Long id, @PathVariable Long fId, @RequestBody AppUser user) {
        return ResponseEntity.ok(userService.removeFriend(id, fId, user));
    }
    
    
//    @GetMapping("/{id}/groups")  // group titles
//    public ResponseEntity<List<String>> getGroups(@PathVariable Long id) {
//        return ResponseEntity.ok(chatService.getGroups(id));
//    }
//    @PostMapping("/{id}/create-group") // ?title=  , [user ids]
//    public ResponseEntity<ChatGroup> createGroup(@PathVariable Long id,@RequestParam String title, @RequestBody List<Long> users) {
//        return ResponseEntity.ok(chatService.createGroup(id, title, users));
//    }
//    @PutMapping("/{id}/join-group/{gId}")
//    public ResponseEntity<ChatGroup> joinGroup(@PathVariable Long id, @PathVariable Long gId) {
//        return ResponseEntity.ok(chatService.joinGroup(id, gId));
//    }
//    @DeleteMapping("/{id}/leave-group/{gId}")
//    public ResponseEntity<String> leaveGroup(@PathVariable Long id, @PathVariable Long gId) {
//        return ResponseEntity.ok(chatService.leaveGroup(id, gId));
//    }
    
    
    @PutMapping("/{id}/favourites/{pId}")
    public ResponseEntity<AppUser> addToFavourites(@PathVariable Long id, @PathVariable Long pId, @RequestBody AppUser user) {
        return ResponseEntity.ok(userService.addToFavourites(id, pId, user));
    }
    @DeleteMapping("/{id}/favourites/{pId}")
    public ResponseEntity<String> removeFromFavourites(@PathVariable Long id, @PathVariable Long pId, @RequestBody AppUser user) {
        return ResponseEntity.ok(userService.removeFromFavourites(id, pId, user));
    }
    
    
    @GetMapping("/{id}/history")
    public ResponseEntity<AppUser> getWatchHistory(@PathVariable Long id, @RequestBody AppUser user) {
        return ResponseEntity.ok(userService.getWatchHistory(id, user));
    }
    
    @PutMapping("/{id}/share/{vId}")
    public ResponseEntity<HashMap<Long, List<Long>>> shareWithFriends(@PathVariable Long id, @PathVariable Long vId, @RequestBody List<Long> friendsLists) {
        return ResponseEntity.ok(userService.shareWithFriends(id, vId, friendsLists));
    }
    
    @GetMapping("/{id}/bookmarks")
    public ResponseEntity<List<HashMap<Long, LocalDateTime>>> getBookmarks(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getBookmarks(id));
    }
    @PutMapping("/{id}/add-bookmark/{vId}")
    public ResponseEntity<List<HashMap<Long, LocalDateTime>>> addToBookmarks(@PathVariable Long id, @PathVariable Long vId, @RequestBody LocalDateTime timestamp) {
        return ResponseEntity.ok(userService.addToBookmarks(id, vId, timestamp));
    }
    @DeleteMapping("/{id}/remove-bookmark/{vId}")
    public ResponseEntity<String> removeFromBookmarks(@PathVariable Long id, @PathVariable Long vId) {
        return ResponseEntity.ok(userService.removeFromBookmarks(id, vId));
    }
    
}

/** 

- `POST /register` - User registration
- `POST /login` - User login
- `GET /validate` - Validate token
- `POST /logout` - Invalidate session
- `POST /reset` - Reset password ( email/phone otp )


- `GET /user/{id}` - Get user profile
- `PUT /user/{id}` - Update user profile
- `GET /user/watchlist` - Get user watchlist
- `POST /user/watchlist` - Add to watchlist
- `DELETE /user/watchlist/{videoId}` - Remove from watchlist
- `GET /user/history` - Get user watch history



Add/Get/Remove Friends - 
Join/Get/Leave Groups

Watchlater / Likes List / Favourites - add & remove
Watch History - get (all clicks)

Recommended Videos by Friends - get
Recommend Videos To Friends - put, (vId, friendslist)


**/